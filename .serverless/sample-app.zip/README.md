# battles-backend

Serverless config was at serverless.yml

To deploy run the command: serverless deploy

 Service is deployed at: https://n97x5g3hyl.execute-api.us-east-2.amazonaws.com/dev/
    API end points are:
      /list
      /count
      /search
